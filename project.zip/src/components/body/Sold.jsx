const Sold = () => {
    return (
        <>
            <p className='font-segoe font-bold text-42 mb-10'>
                Ooops... SOLD OUT
            </p>
        </>
    );
  };
  
export default Sold;